# iOS Interview Test Project

## Email instructions

- Attached is a zip file containing the source code for an app you will complete.  
- Once you have compiled the app, follow the instructions in:
    1. FeedViewController.swift
    2. FeedProvider.swift
    3. FeedResponse.swift
    4. FeedItem.swift
-  After you complete the implementation, write some Unit tests that will cover different cases and aspects of the application’s behavior. For more detailed instructions, check the WebMDInterviewTest-UnitTests.swift file.




