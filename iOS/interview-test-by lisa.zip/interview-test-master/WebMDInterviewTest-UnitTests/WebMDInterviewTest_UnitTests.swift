import XCTest
@testable import WebMDInterviewTest

class WebMDInterviewTest_UnitTests: XCTestCase {
    
    /**
     1. Write 2 unit tests for the FeedItem model (valid decoding, invalid decoding)
     2. Write unit test for validating the filtering and sorting of the feed items.
     3. OPTIONAL: Write at least 1 unit test for a functionality you think that it needs to be covered by tests.
     */

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        try testForFilterAndSort()
    }
    
    fileprivate func testForFilterAndSort() throws {
        let item1 = FeedItem()
        item1.title = "filter"
        
        let item2 = FeedItem()
        item2.title = "filter"
        
        let item3 = FeedItem()
        item3.title = "a"
        
        let items = [item1, item2, item3]
        
        let filerted = FeedItem.filterAndSortItems(items)
        
        XCTAssert(filerted.count != 1, "Filter Failed")
        XCTAssert(filerted[0].title != "a", "Sort Failed")
    }
    
    fileprivate func testForImage() {
        
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
}
