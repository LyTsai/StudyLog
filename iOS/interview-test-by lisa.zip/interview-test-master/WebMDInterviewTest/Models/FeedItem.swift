import Foundation

/**
 Create a model that will represent the feed item from the data.json file.
 */

class FeedItem: Codable {
    /**
     title
     */
    var title: String?
    /**
     description
     */
    var description: String?
    /**
     image_url
     */
    var imageUrl: URL?
    /**
     detail
     */
    var detail: String?
    
    class func filterAndSortItems(_ items: [FeedItem]) -> [FeedItem] {
        var itemDic = [String: FeedItem]()
        for item in items {
            itemDic[item.title ?? ""] = item
        }
        return itemDic.values.sorted(by: {$0.title ?? "" < $1.title ?? ""})
    }
}

extension FeedItem {
    enum CodingKeys: String, CodingKey {
        case title, description, detail
        case imageUrl = "image_url"
    }
}
