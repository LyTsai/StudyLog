//
//  FeedItemViewController.swift
//  WebMDInterviewTest
//
//  Created by Lydire Tsai on 2022/9/14.
//

import Foundation
import UIKit

class FeedItemViewController: UIViewController {
    @IBOutlet weak var imageHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var feedImageView: UIImageView!
    @IBOutlet weak var feedItemInfoTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        adjustImageHeight()
    }
    
    fileprivate func adjustImageHeight() {
        var estimatedHeight: CGFloat = 0
        if let imageSize = feedImageView.image?.size {
            let imageHRatio = imageSize.height / max(imageSize.width, 1)
            estimatedHeight = min(UIScreen.main.bounds.height * 0.3, imageHRatio * feedImageView.frame.width)
        }
        self.imageHeightConstraint.constant = estimatedHeight
    }
    
    func setupWithFeedItem(_ feedItem: FeedItem) {
        navigationItem.title = feedItem.title
        // image
        feedImageView.loadWebImage(feedItem.imageUrl) { image in
            self.adjustImageHeight()
        }
        
        // text
        let detailInfo = NSMutableAttributedString(string: feedItem.description ?? "", attributes: [.font: UIFont.systemFont(ofSize: 14)])
        detailInfo.append(NSAttributedString(string: "\n\n\t\(feedItem.detail ?? "")", attributes: [.font: UIFont.systemFont(ofSize: 14)]))
        
        feedItemInfoTextView.attributedText = detailInfo
    }
}
