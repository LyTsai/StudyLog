//
//  FeedItemCell.swift
//  WebMDInterviewTest
//
//  Created by Lydire Tsai on 2022/9/14.
//

import Foundation
import UIKit

let FeedItemCellID = "Feed Item Cell Identifier"
class FeedItemCell: UITableViewCell {
    @IBOutlet weak var imageHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var textViewHeightContraint: NSLayoutConstraint!
    
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var detailTextView: UITextView!
    
    fileprivate weak var table: FeedListTableView?
    class func cellWithTable(_ table: FeedListTableView, item: FeedItem) -> FeedItemCell {
        var itemCell = table.dequeueReusableCell(withIdentifier: FeedItemCellID) as? FeedItemCell
        if itemCell == nil {
            itemCell = Bundle.main.loadNibNamed("FeedItemCell", owner: self, options: nil)?.first as? FeedItemCell
//            itemCell = FeedItemCell(style: .default, reuseIdentifier: FeedItemCellID)
            // setup
            itemCell?.setupSubviews()
            itemCell?.configureWithItem(item)
        }
        
        itemCell?.table = table
        return itemCell!
    }
    
    fileprivate func setupSubviews() {
        // basic setups
        itemImageView.layer.shadowRadius = 4
        itemImageView.layer.shadowColor = UIColor.black.cgColor
        itemImageView.layer.shadowOpacity = 0.3
        itemImageView.layer.shadowOffset = CGSize(width: 0, height: 2)
    }
    
    fileprivate var imageHRatio: CGFloat = 0 {
        didSet {
            if imageHRatio != oldValue {
                imageHeightConstraint.constant = itemImageView.frame.width * imageHRatio
                self.updateConstraints()
                
                table?.beginUpdates()
                table?.endUpdates()
            }
        }
    }
    // data
    fileprivate func configureWithItem(_ item: FeedItem) {
        itemImageView.loadWebImage(item.imageUrl, loaded: { image in
            if let imageSize = image?.size {
                self.imageHRatio = imageSize.height / max(imageSize.width, 0)
            }else {
                self.imageHRatio = 0
            }
        })
        
        let attributedText = NSMutableAttributedString(string: item.title ?? "", attributes: [.font: UIFont.systemFont(ofSize: 16, weight: .bold)])
        attributedText.append(NSAttributedString(string: "\n\(item.description ?? "")", attributes: [.font: UIFont.systemFont(ofSize: 14), .foregroundColor: UIColor.darkGray]))
        detailTextView.attributedText = attributedText
        // update for textview
        calculateForTextView()

        table?.beginUpdates()
        table?.endUpdates()
    }
    
    fileprivate func calculateForTextView() {
        detailTextView.sizeToFit()
        textViewHeightContraint.constant = detailTextView.frame.height + 10
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
  
        // image width changed
        imageHeightConstraint.constant = itemImageView.frame.width * imageHRatio
        self.updateConstraints()
        
        calculateForTextView()
    }
}
