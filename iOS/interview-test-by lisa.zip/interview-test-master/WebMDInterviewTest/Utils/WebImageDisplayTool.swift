//
//  WebImageDisplayTool.swift
//  WebMDInterviewTest
//
//  Created by Lydire Tsai on 2022/9/14.
//

import Foundation
import UIKit
import SDWebImage

/*
 if the Xcode Edition is not fit, please update the package in terminal first.cd to the project's root directory and use this command:
 carthage update --platform iOS --use-xcframeworks
 */
extension UIImageView {
    func loadWebImage(_ imageUrl: URL?, loaded: ((UIImage?) -> Void)?) {
        self.sd_setImage(with: imageUrl, placeholderImage: UIImage(named: ""), options: .forceTransition, progress: nil, completed: { image, error, type, url in
            loaded?(image)
        })
    }
}
